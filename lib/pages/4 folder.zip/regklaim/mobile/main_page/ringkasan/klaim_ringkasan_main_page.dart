import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:joss_app/blocs/klaimringkas/klaimringkascari_bloc.dart';
import 'package:joss_app/blocs/klaimringkas/mstatusringkascari_bloc.dart';
import 'package:joss_app/common/constants.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:joss_app/helper/expert_helper.dart';
import 'package:joss_app/helper/mobile_expert_helper.dart';
import 'package:joss_app/widgets/EmptyStateWidget.dart';
import 'package:joss_app/widgets/apptheme/polis_button.dart';
import 'package:joss_app/widgets/apptheme/popup_widget.dart';

import 'klaim_ringkasan_status_widget.dart';
import 'klaim_ringkasan_table_widget.dart';

class KlaimRingkasanMainPage extends StatefulWidget {
  const KlaimRingkasanMainPage({super.key});

  @override
  State<KlaimRingkasanMainPage> createState() => _KlaimRingkasanMainPageState();
}

class _KlaimRingkasanMainPageState extends State<KlaimRingkasanMainPage> {
  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      refreshData();
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MultiBlocListener(
      listeners: [
        BlocListener<MstatusringkasCariBloc, MstatusringkasCariState>(
          listenWhen: (previous, current) =>
          previous.selectedStatusId != current.selectedStatusId,
          listener: (context, state) {
            context.read<KlaimringkasCariBloc>().add(
              RefreshKlaimringkasCariEvent(
                selectedStatusId: state.selectedStatusId,
              ),
            );
          },
        ),
      ],
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _buildHeader(context),
          Expanded(child: _buildBody(context)),
        ],
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Container(
      color: secondaryBlackColor,
      padding: EdgeInsets.symmetric(
        horizontal: hPadding * 1.5,
        vertical: hPadding,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              PolisButton(
                assetPath: "assets/icons/unduh.svg",
                bgColor: bGrey,
                borderColor: bdGrey,
                onTap: () => _showExportDialog(context),
                iconSize: 16,
                height: 36,
                width: 36,
              ),
              const SizedBox(width: 8),
              PolisButton(
                assetPath: "assets/icons/bagikan.svg",
                bgColor: bBlue,
                borderColor: bdBlue,
                onTap: () => _onShare(context),
                iconSize: 16,
                height: 36,
                width: 36,
              ),
            ],
          ),
          const SizedBox(height: hPadding),
          const KlaimRingkasanStatusWidget(),
        ],
      ),
    );
  }

  Widget _buildBody(BuildContext context) {
    return BlocBuilder<KlaimringkasCariBloc, KlaimringkasCariState>(
      builder: (context, s) {
        final statusId = context.select<MstatusringkasCariBloc, String>(
              (b) => b.state.selectedStatusId,
        );

        if (s.status == ListStatus.initial ||
            s.status == ListStatus.loadingMore) {
          return const Center(child: CircularProgressIndicator());
        }

        if (s.status == ListStatus.failure) {
          return const Center(child: Text('Failed to fetch data'));
        }

        if (s.items.isEmpty) {
          return EmptyStateWidget(statusId: statusId);
        }

        return KlaimRingkasanTableWidget();
      },
    );
  }

  void refreshData() {
    final statusId =
        context.read<MstatusringkasCariBloc>().state.selectedStatusId;

    context.read<KlaimringkasCariBloc>().add(
      RefreshKlaimringkasCariEvent(
        selectedStatusId: statusId,
      ),
    );
  }

  List<Map<String, dynamic>> _exportRows() {
    final st = context.read<KlaimringkasCariBloc>().state;
    return st.items
        .map((d) => {
      "No": d.nourut,
      "Kategori": d.cobNama,
      "Total Nilai": d.klaimQty,
      "Jumlah Klaim": d.klaimAmount,
    })
        .toList();
  }

  CategoryType _exportCategory() => CategoryType.klaim;

  void _showExportDialog(BuildContext context) {
    final rows = _exportRows();
    if (rows.isEmpty) {
      ScaffoldMessenger.of(context)
          .showSnackBar(infoSnackBar("Tidak ada data untuk diekspor"));
      return;
    }

    showGeneralDialog(
      context: context,
      barrierDismissible: true,
      barrierLabel: "Tutup",
      barrierColor: Colors.black.withOpacity(0.6),
      transitionDuration: const Duration(milliseconds: 250),
      pageBuilder: (context, animation, secondaryAnimation) {
        return Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: const EdgeInsets.symmetric(horizontal: 24),
          child: IntrinsicHeight(
            child: PopupWidget(
              title: "Pilih format file untuk diunduh",
              subtitle: "Tersedia Excel dan PDF",
              button1Text: "Excel",
              button2Text: "PDF",
              onExportSelected: (format) async {
                Navigator.pop(context);
                await _exportData(context, format, rows);
              },
            ),
          ),
        );
      },
      transitionBuilder: (context, animation, secondaryAnimation, child) =>
          FadeTransition(
            opacity: animation,
            child: ScaleTransition(
              scale: CurvedAnimation(parent: animation, curve: Curves.easeOutBack),
              child: child,
            ),
          ),
    );
  }

  Future<void> _exportData(
      BuildContext context,
      ExportFormat format,
      List<Map<String, dynamic>> rows,
      ) async {
    final ext = (format == ExportFormat.excel) ? "xlsx" : "pdf";
    final exportFormat = (format == ExportFormat.excel) ? "excel" : "pdf";
    final fileName =
        "Ringkasan Klaim_${DateTime.now().millisecondsSinceEpoch}.$ext";

    try {
      if (kIsWeb) {
        await ExportHelper.export(exportFormat, rows, _exportCategory());
      } else {
        await MobileDownloadHelper.download(
          context: context,
          fileName: fileName,
          data: rows,
          format: exportFormat,
        );
      }
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          successSnackBar("Berhasil ekspor ${rows.length} item"),
        );
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          errorSnackBar("Gagal ekspor: $e"),
        );
      }
    }
  }

  void _onShare(BuildContext context) {
    final rows = _exportRows();
    if (rows.isEmpty) {
      ScaffoldMessenger.of(context)
          .showSnackBar(infoSnackBar("Tidak ada data untuk diekspor"));
      return;
    }

    String fmt(dynamic v) {
      if (v == null) return "-";
      if (v is num) return NumberFormat.decimalPattern().format(v);
      return v.toString();
    }

    final detailText = rows.map((m) {
      final parts =
      m.entries.map((e) => "${e.key}: ${fmt(e.value)}").join(" | ");
      return "• $parts";
    }).join("\n");

    final message = '''
📄 Ringkasan Klaim

Jumlah Data: ${rows.length}

Detail:
$detailText
''';

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(Icons.share, color: primaryColor),
                  const SizedBox(width: 10),
                  Text("Bagikan Ringkasan Klaim",
                      style: bodyTextStyle(context)),
                ],
              ),
              const SizedBox(height: 12),
              Text("Total data terpilih: ${rows.length}",
                  style: bodyTextStyle(context, fontSize: 14)),
              const SizedBox(height: 20),
              AppButton.iconLeft(
                text: "Salin Rincian",
                icon: const Icon(Icons.copy),
                onPressed: () {
                  Clipboard.setData(ClipboardData(text: message));
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    successSnackBar("Rincian berhasil disalin"),
                  );
                },
              ),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                child: TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text("Batal"),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}